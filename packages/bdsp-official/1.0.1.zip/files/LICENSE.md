auto-bdsp-rng is licensed as GPL-3.0-or-later.

This repository is intended to be distributed under the GPL-3.0-or-later
license declared in pyproject.toml. Third-party components under third_party/
keep their own upstream licenses.

